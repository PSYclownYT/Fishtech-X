particle minecraft:white_smoke ~25 ~ ~ 0 50 50 0 10000 force @a
particle minecraft:white_smoke ~-25 ~ ~ 0 50 50 0 10000 force @a
particle minecraft:white_smoke ~ ~ ~25 50 50 0 0 10000 force @a
particle minecraft:white_smoke ~ ~ ~-25 50 50 0 0 10000 force @a
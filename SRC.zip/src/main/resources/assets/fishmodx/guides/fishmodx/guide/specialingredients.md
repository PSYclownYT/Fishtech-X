---
navigation:
  title: Special Ingredients
  icon: fishmodx:advanced_circuit
item_ids:
    - fishmodx:tungsten
    - fishmodx:plastic_sheet
    - fishmodx:copper_plate
    - fishmodx:iron_plate
    - fishmodx:mechanical_press
    - fishmodx:refinery
---

# Special Ingredients
There are many special ingredients in the mod such as Plates, Plastic, and Tungsten.
### Plates
Iron and Copper plates are created using a <ItemLink id="fishmodx:mechanical_press" />.
A thing about mechanical presses is that they have no GUI. you must autonomously feed items into and out of them.
<GameScene>
  <ImportStructure src="mechpress.snbt" />
</GameScene>

Mechanical Presses are crafted like so.
<RecipeFor id="fishmodx:mechanical_press" />

### Plastic
Plastic is made by distilling Oil, a naturally spawning fluid found underground.
In order to find oil easier, you can use the <ItemLink id="fishmodx:oil_finder"/>.
<RecipeFor id="fishmodx:oil_finder" />

The Oil distillery is used like so: oil goes in one side, and plastic comes out the other.
<GameScene>
    <ImportStructure src="distillery.snbt" />
</GameScene>

### Tungsten
Tungsten is made as a byproduct of refining lithium ore. For each lithium ore processed, it has a 1 in 5 chance of dropping one lithium ore on the ground.

Here is a setup to create tungsten:

<GameScene zoom="2">
  <ImportStructure src="tungstenautomationsetup.snbt" />
</GameScene>
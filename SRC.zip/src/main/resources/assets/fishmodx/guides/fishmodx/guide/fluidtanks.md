---
navigation:
  # Title shown in the navigation bar
  title: Fluid Tanks
  icon: fluidtank:tank_iron
  position: 2
---
# Fluid Tanks
Fluid tanks are one of the core parts of FishTech! 
<GameScene zoom="2">
  <ImportStructure src="fluidtanks.snbt" />
</GameScene>


## Wooden Tanks
Wooden tanks are the most basic form of fluid tank.

These can hold `8000 mb` of fluid.
<RecipeFor id="fluidtank:tank_wood"/>

## Stone Tanks
Stone tanks are the next tier of fluid tank.

These can hold `16000 mB` of fluid.
<RecipeFor id="fluidtank:tank_stone"/>

The following tank recipies will be listed as follows:
<RecipeFor id="fluidtank:tank_iron"/>
<RecipeFor id="fluidtank:tank_gold"/>
<RecipeFor id="fluidtank:tank_diamond"/>
<RecipeFor id="fluidtank:tank_emerald"/>
<RecipeFor id="fluidtank:tank_star"/>
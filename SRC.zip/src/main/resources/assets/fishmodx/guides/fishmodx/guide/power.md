---
navigation:
  title: Power Generation
  icon: fishmodx:modular_battery
item_ids:
    - fishmodx:furnace_generator
    - fishmodx:lava_generator
    - fishmodx:hand_crank
---
# Power Generation

There are 2 main ways of generating power through Fishtech, as well as Hand cranks.

### Hand Cranks
<RecipeFor id="fishmodx:hand_crank" />
### Furnace Generators
The Earlygame generation solution is <ItemLink id="fishmodx:furnace_generator" />s. These input any furnace fuel, and output 100 FE per item smelted.

<GameScene zoom="2">
  <ImportStructure src="furnacegen.snbt" />
</GameScene>

They are one of the most inexpensive items in Fishtech X.

<RecipeFor id="fishmodx:furnace_generator" />

### Lava Generators
The Second generation solution is <ItemLink id="fishmodx:lava_generator" />s. These input any lava from a tank and output FE.

<GameScene zoom="4">
    <ImportStructure src="lavagenerator.snbt" />
</GameScene>
<RecipeFor id="fishmodx:lava_generator"/>


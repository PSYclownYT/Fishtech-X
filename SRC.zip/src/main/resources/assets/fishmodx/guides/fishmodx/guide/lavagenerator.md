---
navigation:
  # Title shown in the navigation bar
  title: Lava Generator
  icon: fishmodx:lava_generator
  position: 3
---
# Lava Generator

Lava generators are an earlygame power source.
Provide with a fluid tank, they will convert lava (in mB) to energy at 100 FE /2s

<GameScene zoom="2">
  <ImportStructure src="scenes/lavagenerator.snbt" />
</GameScene>
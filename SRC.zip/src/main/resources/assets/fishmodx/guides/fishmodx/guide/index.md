---
navigation:
  title: Getting Started
  icon: minecraft:cod
---

# Getting Started

Welcome to Fishtech X!
this is a project of mine, inspired by Oritech, HBM, and Skyfactory.
Make sure to check back here if you are ever confused!

To start, you will need to look into [Power generation](./power.md).
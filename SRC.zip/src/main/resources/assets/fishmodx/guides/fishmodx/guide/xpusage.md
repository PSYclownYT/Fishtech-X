---
navigation:
  title: Liquid XP
  icon: fishmodx:liquid_xp_bucket
item_ids:
    - fishmodx:mob_grinder
    - fishmodx:x_pshower
---
# Liquid XP

Liquid XP can be generated in a few ways, and is used as a way of rewarding the player for good logistics.

### Mob Grinder

The Mob Grinder is a block that resembles a fence. when collided with, it fills it's internal tank with `100Mb` of Liquid XP

<RecipeFor id="fishmodx:mob_grinder"/>

### Refinery
When using the Refinery, if a tank is placed on top of it, it will fill the tank depending on the recipe. purifying lithium will provide more XP than extracting gravel.

<RecipeFor id="fishmodx:refinery"/>

### XP Shower
When pumped with XP, it acts as a redstone output that will spit out XP orbs. 

<RecipeFor id="fishmodx:x_pshower"/>
<GameScene>
    <ImportStructure src="xpshower.snbt" />
</GameScene>
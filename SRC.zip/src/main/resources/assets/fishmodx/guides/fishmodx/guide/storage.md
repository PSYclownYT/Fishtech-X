---
navigation:
  title: Storage Logistics
  icon: minecraft:chest
item_ids:
    - fishmodx:modular_battery
    - fluidtank:tank_wood
    - fluidtank:tank_stone
    - fluidtank:tank_iron
    - fluidtank:tank_gold
    - fluidtank:tank_diamond
---

# Storage Logistics

While we do have applied energistics 2, where you can read the wiki <CommandLink command="/guidemec ae2:guide open">Here,</CommandLink> There are some new storage methods that are much earlier game than those of ae2.

### Modular Battery
<RecipeFor id="fishmodx:modular_battery" />
The modular battery is a block that stores 50,000 FE, and can be stacked. Power should be drawn from the BOTTOM of the stack, not the top.
<GameScene>
    <ImportStructure src="batterysetup.snbt" />
</GameScene>

### Fluid Tanks
[View info HERE](./fluidtanks.md)
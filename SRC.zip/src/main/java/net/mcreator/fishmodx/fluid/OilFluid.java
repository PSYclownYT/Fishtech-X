package net.mcreator.fishmodx.fluid;

import net.neoforged.neoforge.fluids.BaseFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;

import net.mcreator.fishmodx.init.FishmodxModItems;
import net.mcreator.fishmodx.init.FishmodxModFluids;
import net.mcreator.fishmodx.init.FishmodxModFluidTypes;
import net.mcreator.fishmodx.init.FishmodxModBlocks;

public abstract class OilFluid extends BaseFlowingFluid {
	public static final BaseFlowingFluid.Properties PROPERTIES = new BaseFlowingFluid.Properties(() -> FishmodxModFluidTypes.OIL_TYPE.get(), () -> FishmodxModFluids.OIL.get(), () -> FishmodxModFluids.FLOWING_OIL.get()).explosionResistance(100f)
			.tickRate(30).bucket(() -> FishmodxModItems.OIL_BUCKET.get()).block(() -> (LiquidBlock) FishmodxModBlocks.OIL.get());

	private OilFluid() {
		super(PROPERTIES);
	}

	public static class Source extends OilFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends OilFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
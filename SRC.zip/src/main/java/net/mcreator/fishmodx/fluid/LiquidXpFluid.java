package net.mcreator.fishmodx.fluid;

import net.neoforged.neoforge.fluids.BaseFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;

import net.mcreator.fishmodx.init.FishmodxModItems;
import net.mcreator.fishmodx.init.FishmodxModFluids;
import net.mcreator.fishmodx.init.FishmodxModFluidTypes;
import net.mcreator.fishmodx.init.FishmodxModBlocks;

public abstract class LiquidXpFluid extends BaseFlowingFluid {
	public static final BaseFlowingFluid.Properties PROPERTIES = new BaseFlowingFluid.Properties(() -> FishmodxModFluidTypes.LIQUID_XP_TYPE.get(), () -> FishmodxModFluids.LIQUID_XP.get(), () -> FishmodxModFluids.FLOWING_LIQUID_XP.get())
			.explosionResistance(100f).bucket(() -> FishmodxModItems.LIQUID_XP_BUCKET.get()).block(() -> (LiquidBlock) FishmodxModBlocks.LIQUID_XP.get());

	private LiquidXpFluid() {
		super(PROPERTIES);
	}

	public static class Source extends LiquidXpFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends LiquidXpFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
package net.mcreator.fishmodx.fluid;

import net.neoforged.neoforge.fluids.BaseFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.ParticleOptions;

import net.mcreator.fishmodx.init.FishmodxModItems;
import net.mcreator.fishmodx.init.FishmodxModFluids;
import net.mcreator.fishmodx.init.FishmodxModFluidTypes;
import net.mcreator.fishmodx.init.FishmodxModBlocks;

public abstract class MoltenIronFluid extends BaseFlowingFluid {
	public static final BaseFlowingFluid.Properties PROPERTIES = new BaseFlowingFluid.Properties(() -> FishmodxModFluidTypes.MOLTEN_IRON_TYPE.get(), () -> FishmodxModFluids.MOLTEN_IRON.get(), () -> FishmodxModFluids.FLOWING_MOLTEN_IRON.get())
			.explosionResistance(100f).bucket(() -> FishmodxModItems.MOLTEN_IRON_BUCKET.get()).block(() -> (LiquidBlock) FishmodxModBlocks.MOLTEN_IRON.get());

	private MoltenIronFluid() {
		super(PROPERTIES);
	}

	@Override
	public ParticleOptions getDripParticle() {
		return ParticleTypes.ASH;
	}

	public static class Source extends MoltenIronFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends MoltenIronFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
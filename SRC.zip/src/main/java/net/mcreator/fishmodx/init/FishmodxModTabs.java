/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.fishmodx.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.fishmodx.FishmodxMod;

public class FishmodxModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, FishmodxMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> FISH_TECH_2 = REGISTRY.register("fish_tech_2",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.fishmodx.fish_tech_2")).icon(() -> new ItemStack(Items.COD)).displayItems((parameters, tabData) -> {
				tabData.accept(FishmodxModBlocks.LAVA_GENERATOR.get().asItem());
				tabData.accept(FishmodxModBlocks.HAND_CRANK.get().asItem());
				tabData.accept(FishmodxModBlocks.FURNACE_GENERATOR.get().asItem());
				tabData.accept(FishmodxModBlocks.MODULAR_BATTERY.get().asItem());
				tabData.accept(FishmodxModItems.ORE_HAMMER.get());
				tabData.accept(FishmodxModItems.FISHOMETER.get());
				tabData.accept(FishmodxModBlocks.COBBLESTONE_GENERATOR.get().asItem());
				tabData.accept(FishmodxModBlocks.REFINERY.get().asItem());
				tabData.accept(FishmodxModBlocks.X_PSHOWER.get().asItem());
				tabData.accept(FishmodxModBlocks.MELTER.get().asItem());
				tabData.accept(FishmodxModBlocks.CRUSHINGMILL.get().asItem());
				tabData.accept(FishmodxModBlocks.ZACHS_ROUTER.get().asItem());
				tabData.accept(FishmodxModItems.DEBUG_WAND.get());
				tabData.accept(FishmodxModItems.ITEM_DEBUGGER.get());
				tabData.accept(FishmodxModBlocks.ARC_FURNACE.get().asItem());
				tabData.accept(FishmodxModBlocks.MECHANICAL_PRESS.get().asItem());
				tabData.accept(FishmodxModBlocks.LITHIUM_ORE.get().asItem());
				tabData.accept(FishmodxModBlocks.MOB_GRINDER.get().asItem());
				tabData.accept(FishmodxModItems.OIL_FINDER.get());
			}).build());
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> FISHTECH_X_INGREDIENTS = REGISTRY.register("fishtech_x_ingredients",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.fishmodx.fishtech_x_ingredients")).icon(() -> new ItemStack(FishmodxModItems.URANIUM.get())).displayItems((parameters, tabData) -> {
				tabData.accept(FishmodxModItems.MESH.get());
				tabData.accept(FishmodxModItems.COPPER_NUGGET.get());
				tabData.accept(FishmodxModItems.STEEL.get());
				tabData.accept(FishmodxModItems.LITHIUM_INGOT.get());
				tabData.accept(FishmodxModBlocks.LITHIUM_BLOCK.get().asItem());
				tabData.accept(FishmodxModItems.TUNGSTEN.get());
				tabData.accept(FishmodxModItems.URANIUM.get());
				tabData.accept(FishmodxModItems.STONE_DUST.get());
				tabData.accept(FishmodxModItems.SILICON.get());
				tabData.accept(FishmodxModItems.SILICON_WAFER.get());
				tabData.accept(FishmodxModItems.PLASTIC_SHEET.get());
				tabData.accept(FishmodxModItems.BASIC_CIRCUIT.get());
				tabData.accept(FishmodxModItems.ADVANCED_CIRCUIT.get());
				tabData.accept(FishmodxModItems.COPPER_PLATE.get());
				tabData.accept(FishmodxModItems.IRON_PLATE.get());
			}).withTabsBefore(FISH_TECH_2.getId()).build());
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> FISHTECH_X_FLUIDS = REGISTRY.register("fishtech_x_fluids",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.fishmodx.fishtech_x_fluids")).icon(() -> new ItemStack(FishmodxModItems.MOLTEN_IRON_BUCKET.get())).displayItems((parameters, tabData) -> {
				tabData.accept(FishmodxModItems.MOLTEN_IRON_BUCKET.get());
				tabData.accept(FishmodxModItems.LIQUID_XP_BUCKET.get());
				tabData.accept(FishmodxModItems.OIL_BUCKET.get());
			}).withTabsBefore(FISHTECH_X_INGREDIENTS.getId()).build());
}
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.fishmodx.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.Block;

import net.mcreator.fishmodx.block.*;
import net.mcreator.fishmodx.FishmodxMod;

public class FishmodxModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(FishmodxMod.MODID);
	public static final DeferredBlock<Block> COBBLESTONE_GENERATOR;
	public static final DeferredBlock<Block> LAVA_GENERATOR;
	public static final DeferredBlock<Block> CRUSHINGMILL;
	public static final DeferredBlock<Block> REFINERY;
	public static final DeferredBlock<Block> MOLTEN_IRON;
	public static final DeferredBlock<Block> MELTER;
	public static final DeferredBlock<Block> COOLER;
	public static final DeferredBlock<Block> ZACHS_ROUTER;
	public static final DeferredBlock<Block> MODULAR_BATTERY;
	public static final DeferredBlock<Block> LIQUID_XP;
	public static final DeferredBlock<Block> X_PSHOWER;
	public static final DeferredBlock<Block> LITHIUM_ORE;
	public static final DeferredBlock<Block> LITHIUM_BLOCK;
	public static final DeferredBlock<Block> OIL;
	public static final DeferredBlock<Block> HAND_CRANK;
	public static final DeferredBlock<Block> SIEVE;
	public static final DeferredBlock<Block> FURNACE_GENERATOR;
	public static final DeferredBlock<Block> ARC_FURNACE;
	public static final DeferredBlock<Block> MECHANICAL_PRESS;
	public static final DeferredBlock<Block> OIL_DISTILLER;
	public static final DeferredBlock<Block> MOB_GRINDER;
	static {
		COBBLESTONE_GENERATOR = REGISTRY.register("cobblestone_generator", CobblestoneGeneratorBlock::new);
		LAVA_GENERATOR = REGISTRY.register("lava_generator", LavaGeneratorBlock::new);
		CRUSHINGMILL = REGISTRY.register("crushingmill", CrushingmillBlock::new);
		REFINERY = REGISTRY.register("refinery", RefineryBlock::new);
		MOLTEN_IRON = REGISTRY.register("molten_iron", MoltenIronBlock::new);
		MELTER = REGISTRY.register("melter", MelterBlock::new);
		COOLER = REGISTRY.register("cooler", CoolerBlock::new);
		ZACHS_ROUTER = REGISTRY.register("zachs_router", ZachsRouterBlock::new);
		MODULAR_BATTERY = REGISTRY.register("modular_battery", ModularBatteryBlock::new);
		LIQUID_XP = REGISTRY.register("liquid_xp", LiquidXpBlock::new);
		X_PSHOWER = REGISTRY.register("x_pshower", XPshowerBlock::new);
		LITHIUM_ORE = REGISTRY.register("lithium_ore", LithiumOreBlock::new);
		LITHIUM_BLOCK = REGISTRY.register("lithium_block", LithiumBlockBlock::new);
		OIL = REGISTRY.register("oil", OilBlock::new);
		HAND_CRANK = REGISTRY.register("hand_crank", HandCrankBlock::new);
		SIEVE = REGISTRY.register("sieve", SieveBlock::new);
		FURNACE_GENERATOR = REGISTRY.register("furnace_generator", FurnaceGeneratorBlock::new);
		ARC_FURNACE = REGISTRY.register("arc_furnace", ArcFurnaceBlock::new);
		MECHANICAL_PRESS = REGISTRY.register("mechanical_press", MechanicalPressBlock::new);
		OIL_DISTILLER = REGISTRY.register("oil_distiller", OilDistillerBlock::new);
		MOB_GRINDER = REGISTRY.register("mob_grinder", MobGrinderBlock::new);
	}
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
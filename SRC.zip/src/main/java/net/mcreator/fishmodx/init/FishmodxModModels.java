/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.fishmodx.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.fishmodx.client.model.Modelwhay;
import net.mcreator.fishmodx.client.model.Modelmodel;
import net.mcreator.fishmodx.client.model.ModelSieve;
import net.mcreator.fishmodx.client.model.ModelHandCrank;

@EventBusSubscriber(Dist.CLIENT)
public class FishmodxModModels {
	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(Modelmodel.LAYER_LOCATION, Modelmodel::createBodyLayer);
		event.registerLayerDefinition(ModelHandCrank.LAYER_LOCATION, ModelHandCrank::createBodyLayer);
		event.registerLayerDefinition(Modelwhay.LAYER_LOCATION, Modelwhay::createBodyLayer);
		event.registerLayerDefinition(ModelSieve.LAYER_LOCATION, ModelSieve::createBodyLayer);
	}
}
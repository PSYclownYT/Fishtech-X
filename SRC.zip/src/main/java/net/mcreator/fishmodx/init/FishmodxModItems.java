/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.fishmodx.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.fluids.capability.wrappers.FluidBucketWrapper;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.fishmodx.item.*;
import net.mcreator.fishmodx.FishmodxMod;

@EventBusSubscriber
public class FishmodxModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(FishmodxMod.MODID);
	public static final DeferredItem<Item> COBBLESTONE_GENERATOR;
	public static final DeferredItem<Item> LAVA_GENERATOR;
	public static final DeferredItem<Item> CRUSHINGMILL;
	public static final DeferredItem<Item> FISHOMETER;
	public static final DeferredItem<Item> REFINERY;
	public static final DeferredItem<Item> MOLTEN_IRON_BUCKET;
	public static final DeferredItem<Item> MELTER;
	public static final DeferredItem<Item> COOLER;
	public static final DeferredItem<Item> ZACHS_ROUTER;
	public static final DeferredItem<Item> MODULAR_BATTERY;
	public static final DeferredItem<Item> LIQUID_XP_BUCKET;
	public static final DeferredItem<Item> DEBUG_WAND;
	public static final DeferredItem<Item> X_PSHOWER;
	public static final DeferredItem<Item> COPPER_NUGGET;
	public static final DeferredItem<Item> STEEL;
	public static final DeferredItem<Item> SILICON;
	public static final DeferredItem<Item> LITHIUM_INGOT;
	public static final DeferredItem<Item> LITHIUM_ORE;
	public static final DeferredItem<Item> LITHIUM_BLOCK;
	public static final DeferredItem<Item> OIL_BUCKET;
	public static final DeferredItem<Item> TUNGSTEN;
	public static final DeferredItem<Item> URANIUM;
	public static final DeferredItem<Item> HAND_CRANK;
	public static final DeferredItem<Item> ORE_HAMMER;
	public static final DeferredItem<Item> STONE_DUST;
	public static final DeferredItem<Item> MESH;
	public static final DeferredItem<Item> ITEM_DEBUGGER;
	public static final DeferredItem<Item> SIEVE;
	public static final DeferredItem<Item> FURNACE_GENERATOR;
	public static final DeferredItem<Item> SILICON_WAFER;
	public static final DeferredItem<Item> PLASTIC_SHEET;
	public static final DeferredItem<Item> BASIC_CIRCUIT;
	public static final DeferredItem<Item> ARC_FURNACE;
	public static final DeferredItem<Item> ADVANCED_CIRCUIT;
	public static final DeferredItem<Item> COPPER_PLATE;
	public static final DeferredItem<Item> IRON_PLATE;
	public static final DeferredItem<Item> MECHANICAL_PRESS;
	public static final DeferredItem<Item> OIL_DISTILLER;
	public static final DeferredItem<Item> MOB_GRINDER;
	public static final DeferredItem<Item> OIL_FINDER;
	static {
		COBBLESTONE_GENERATOR = block(FishmodxModBlocks.COBBLESTONE_GENERATOR);
		LAVA_GENERATOR = block(FishmodxModBlocks.LAVA_GENERATOR);
		CRUSHINGMILL = block(FishmodxModBlocks.CRUSHINGMILL);
		FISHOMETER = REGISTRY.register("fishometer", FishometerItem::new);
		REFINERY = block(FishmodxModBlocks.REFINERY);
		MOLTEN_IRON_BUCKET = REGISTRY.register("molten_iron_bucket", MoltenIronItem::new);
		MELTER = block(FishmodxModBlocks.MELTER);
		COOLER = block(FishmodxModBlocks.COOLER);
		ZACHS_ROUTER = block(FishmodxModBlocks.ZACHS_ROUTER);
		MODULAR_BATTERY = block(FishmodxModBlocks.MODULAR_BATTERY);
		LIQUID_XP_BUCKET = REGISTRY.register("liquid_xp_bucket", LiquidXpItem::new);
		DEBUG_WAND = REGISTRY.register("debug_wand", DebugWandItem::new);
		X_PSHOWER = block(FishmodxModBlocks.X_PSHOWER);
		COPPER_NUGGET = REGISTRY.register("copper_nugget", CopperNuggetItem::new);
		STEEL = REGISTRY.register("steel", SteelItem::new);
		SILICON = REGISTRY.register("silicon", SiliconItem::new);
		LITHIUM_INGOT = REGISTRY.register("lithium_ingot", LithiumIngotItem::new);
		LITHIUM_ORE = block(FishmodxModBlocks.LITHIUM_ORE);
		LITHIUM_BLOCK = block(FishmodxModBlocks.LITHIUM_BLOCK);
		OIL_BUCKET = REGISTRY.register("oil_bucket", OilItem::new);
		TUNGSTEN = REGISTRY.register("tungsten", TungstenItem::new);
		URANIUM = REGISTRY.register("uranium", UraniumItem::new);
		HAND_CRANK = block(FishmodxModBlocks.HAND_CRANK);
		ORE_HAMMER = REGISTRY.register("ore_hammer", OreHammerItem::new);
		STONE_DUST = REGISTRY.register("stone_dust", StoneDustItem::new);
		MESH = REGISTRY.register("mesh", MeshItem::new);
		ITEM_DEBUGGER = REGISTRY.register("item_debugger", ItemDebuggerItem::new);
		SIEVE = block(FishmodxModBlocks.SIEVE);
		FURNACE_GENERATOR = block(FishmodxModBlocks.FURNACE_GENERATOR);
		SILICON_WAFER = REGISTRY.register("silicon_wafer", SiliconWaferItem::new);
		PLASTIC_SHEET = REGISTRY.register("plastic_sheet", PlasticSheetItem::new);
		BASIC_CIRCUIT = REGISTRY.register("basic_circuit", BasicCircuitItem::new);
		ARC_FURNACE = block(FishmodxModBlocks.ARC_FURNACE);
		ADVANCED_CIRCUIT = REGISTRY.register("advanced_circuit", AdvancedCircuitItem::new);
		COPPER_PLATE = REGISTRY.register("copper_plate", CopperPlateItem::new);
		IRON_PLATE = REGISTRY.register("iron_plate", IronPlateItem::new);
		MECHANICAL_PRESS = block(FishmodxModBlocks.MECHANICAL_PRESS);
		OIL_DISTILLER = block(FishmodxModBlocks.OIL_DISTILLER);
		MOB_GRINDER = block(FishmodxModBlocks.MOB_GRINDER);
		OIL_FINDER = REGISTRY.register("oil_finder", OilFinderItem::new);
	}

	// Start of user code block custom items
	// End of user code block custom items
	@SubscribeEvent
	public static void registerCapabilities(RegisterCapabilitiesEvent event) {
		event.registerItem(Capabilities.FluidHandler.ITEM, (stack, context) -> new FluidBucketWrapper(stack), MOLTEN_IRON_BUCKET.get());
		event.registerItem(Capabilities.FluidHandler.ITEM, (stack, context) -> new FluidBucketWrapper(stack), LIQUID_XP_BUCKET.get());
		event.registerItem(Capabilities.FluidHandler.ITEM, (stack, context) -> new FluidBucketWrapper(stack), OIL_BUCKET.get());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), properties));
	}
}
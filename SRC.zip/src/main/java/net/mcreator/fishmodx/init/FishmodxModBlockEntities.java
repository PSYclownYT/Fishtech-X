/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.fishmodx.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.items.wrapper.SidedInvWrapper;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.Block;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.fishmodx.block.entity.*;
import net.mcreator.fishmodx.FishmodxMod;

@EventBusSubscriber
public class FishmodxModBlockEntities {
	public static final DeferredRegister<BlockEntityType<?>> REGISTRY = DeferredRegister.create(BuiltInRegistries.BLOCK_ENTITY_TYPE, FishmodxMod.MODID);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<CobblestoneGeneratorBlockEntity>> COBBLESTONE_GENERATOR = register("cobblestone_generator", FishmodxModBlocks.COBBLESTONE_GENERATOR, CobblestoneGeneratorBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<LavaGeneratorBlockEntity>> LAVA_GENERATOR = register("lava_generator", FishmodxModBlocks.LAVA_GENERATOR, LavaGeneratorBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<CrushingmillBlockEntity>> CRUSHINGMILL = register("crushingmill", FishmodxModBlocks.CRUSHINGMILL, CrushingmillBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<RefineryBlockEntity>> REFINERY = register("refinery", FishmodxModBlocks.REFINERY, RefineryBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<MelterBlockEntity>> MELTER = register("melter", FishmodxModBlocks.MELTER, MelterBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<CoolerBlockEntity>> COOLER = register("cooler", FishmodxModBlocks.COOLER, CoolerBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ZachsRouterBlockEntity>> ZACHS_ROUTER = register("zachs_router", FishmodxModBlocks.ZACHS_ROUTER, ZachsRouterBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ModularBatteryBlockEntity>> MODULAR_BATTERY = register("modular_battery", FishmodxModBlocks.MODULAR_BATTERY, ModularBatteryBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<XPshowerBlockEntity>> X_PSHOWER = register("x_pshower", FishmodxModBlocks.X_PSHOWER, XPshowerBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<HandCrankBlockEntity>> HAND_CRANK = register("hand_crank", FishmodxModBlocks.HAND_CRANK, HandCrankBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<SieveBlockEntity>> SIEVE = register("sieve", FishmodxModBlocks.SIEVE, SieveBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<FurnaceGeneratorBlockEntity>> FURNACE_GENERATOR = register("furnace_generator", FishmodxModBlocks.FURNACE_GENERATOR, FurnaceGeneratorBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ArcFurnaceBlockEntity>> ARC_FURNACE = register("arc_furnace", FishmodxModBlocks.ARC_FURNACE, ArcFurnaceBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<MechanicalPressBlockEntity>> MECHANICAL_PRESS = register("mechanical_press", FishmodxModBlocks.MECHANICAL_PRESS, MechanicalPressBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<OilDistillerBlockEntity>> OIL_DISTILLER = register("oil_distiller", FishmodxModBlocks.OIL_DISTILLER, OilDistillerBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<MobGrinderBlockEntity>> MOB_GRINDER = register("mob_grinder", FishmodxModBlocks.MOB_GRINDER, MobGrinderBlockEntity::new);

	// Start of user code block custom block entities
	// End of user code block custom block entities
	private static <T extends BlockEntity> DeferredHolder<BlockEntityType<?>, BlockEntityType<T>> register(String registryname, DeferredHolder<Block, Block> block, BlockEntityType.BlockEntitySupplier<T> supplier) {
		return REGISTRY.register(registryname, () -> BlockEntityType.Builder.of(supplier, block.get()).build(null));
	}

	@SubscribeEvent
	public static void registerCapabilities(RegisterCapabilitiesEvent event) {
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, COBBLESTONE_GENERATOR.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, COBBLESTONE_GENERATOR.get(), (blockEntity, side) -> blockEntity.getEnergyStorage());
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, LAVA_GENERATOR.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, LAVA_GENERATOR.get(), (blockEntity, side) -> blockEntity.getEnergyStorage());
		event.registerBlockEntity(Capabilities.FluidHandler.BLOCK, LAVA_GENERATOR.get(), (blockEntity, side) -> blockEntity.getFluidTank());
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, CRUSHINGMILL.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, CRUSHINGMILL.get(), (blockEntity, side) -> blockEntity.getEnergyStorage());
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, REFINERY.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, REFINERY.get(), (blockEntity, side) -> blockEntity.getEnergyStorage());
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, MELTER.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.FluidHandler.BLOCK, MELTER.get(), (blockEntity, side) -> blockEntity.getFluidTank());
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, COOLER.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.FluidHandler.BLOCK, COOLER.get(), (blockEntity, side) -> blockEntity.getFluidTank());
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, ZACHS_ROUTER.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, MODULAR_BATTERY.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, MODULAR_BATTERY.get(), (blockEntity, side) -> blockEntity.getEnergyStorage());
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, X_PSHOWER.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.FluidHandler.BLOCK, X_PSHOWER.get(), (blockEntity, side) -> blockEntity.getFluidTank());
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, HAND_CRANK.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, HAND_CRANK.get(), (blockEntity, side) -> blockEntity.getEnergyStorage());
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, SIEVE.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, FURNACE_GENERATOR.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, FURNACE_GENERATOR.get(), (blockEntity, side) -> blockEntity.getEnergyStorage());
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, ARC_FURNACE.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, ARC_FURNACE.get(), (blockEntity, side) -> blockEntity.getEnergyStorage());
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, MECHANICAL_PRESS.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, MECHANICAL_PRESS.get(), (blockEntity, side) -> blockEntity.getEnergyStorage());
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, OIL_DISTILLER.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, OIL_DISTILLER.get(), (blockEntity, side) -> blockEntity.getEnergyStorage());
		event.registerBlockEntity(Capabilities.FluidHandler.BLOCK, OIL_DISTILLER.get(), (blockEntity, side) -> blockEntity.getFluidTank());
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, MOB_GRINDER.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.FluidHandler.BLOCK, MOB_GRINDER.get(), (blockEntity, side) -> blockEntity.getFluidTank());
	}
}
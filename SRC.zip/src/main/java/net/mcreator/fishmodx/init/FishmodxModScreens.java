/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.fishmodx.init;

import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.fishmodx.client.gui.OutputOnlyScreen;
import net.mcreator.fishmodx.client.gui.OneslotScreen;
import net.mcreator.fishmodx.client.gui.IOGUIScreen;

@EventBusSubscriber(Dist.CLIENT)
public class FishmodxModScreens {
	@SubscribeEvent
	public static void clientLoad(RegisterMenuScreensEvent event) {
		event.register(FishmodxModMenus.ONESLOT.get(), OneslotScreen::new);
		event.register(FishmodxModMenus.IOGUI.get(), IOGUIScreen::new);
		event.register(FishmodxModMenus.OUTPUT_ONLY.get(), OutputOnlyScreen::new);
	}

	public interface ScreenAccessor {
		void updateMenuState(int elementType, String name, Object elementState);
	}
}
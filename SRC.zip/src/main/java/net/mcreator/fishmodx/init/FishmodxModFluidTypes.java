/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.fishmodx.init;

import net.neoforged.neoforge.registries.NeoForgeRegistries;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.fluids.FluidType;

import net.mcreator.fishmodx.fluid.types.OilFluidType;
import net.mcreator.fishmodx.fluid.types.MoltenIronFluidType;
import net.mcreator.fishmodx.fluid.types.LiquidXpFluidType;
import net.mcreator.fishmodx.FishmodxMod;

public class FishmodxModFluidTypes {
	public static final DeferredRegister<FluidType> REGISTRY = DeferredRegister.create(NeoForgeRegistries.FLUID_TYPES, FishmodxMod.MODID);
	public static final DeferredHolder<FluidType, FluidType> MOLTEN_IRON_TYPE = REGISTRY.register("molten_iron", () -> new MoltenIronFluidType());
	public static final DeferredHolder<FluidType, FluidType> LIQUID_XP_TYPE = REGISTRY.register("liquid_xp", () -> new LiquidXpFluidType());
	public static final DeferredHolder<FluidType, FluidType> OIL_TYPE = REGISTRY.register("oil", () -> new OilFluidType());
}
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.fishmodx.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ItemBlockRenderTypes;

import net.mcreator.fishmodx.fluid.OilFluid;
import net.mcreator.fishmodx.fluid.MoltenIronFluid;
import net.mcreator.fishmodx.fluid.LiquidXpFluid;
import net.mcreator.fishmodx.FishmodxMod;

public class FishmodxModFluids {
	public static final DeferredRegister<Fluid> REGISTRY = DeferredRegister.create(BuiltInRegistries.FLUID, FishmodxMod.MODID);
	public static final DeferredHolder<Fluid, FlowingFluid> MOLTEN_IRON = REGISTRY.register("molten_iron", () -> new MoltenIronFluid.Source());
	public static final DeferredHolder<Fluid, FlowingFluid> FLOWING_MOLTEN_IRON = REGISTRY.register("flowing_molten_iron", () -> new MoltenIronFluid.Flowing());
	public static final DeferredHolder<Fluid, FlowingFluid> LIQUID_XP = REGISTRY.register("liquid_xp", () -> new LiquidXpFluid.Source());
	public static final DeferredHolder<Fluid, FlowingFluid> FLOWING_LIQUID_XP = REGISTRY.register("flowing_liquid_xp", () -> new LiquidXpFluid.Flowing());
	public static final DeferredHolder<Fluid, FlowingFluid> OIL = REGISTRY.register("oil", () -> new OilFluid.Source());
	public static final DeferredHolder<Fluid, FlowingFluid> FLOWING_OIL = REGISTRY.register("flowing_oil", () -> new OilFluid.Flowing());

	@EventBusSubscriber(Dist.CLIENT)
	public static class FluidsClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			ItemBlockRenderTypes.setRenderLayer(MOLTEN_IRON.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_MOLTEN_IRON.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(LIQUID_XP.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_LIQUID_XP.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(OIL.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_OIL.get(), RenderType.translucent());
		}
	}
}
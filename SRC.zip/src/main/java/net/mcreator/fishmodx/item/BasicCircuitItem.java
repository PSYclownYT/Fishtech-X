package net.mcreator.fishmodx.item;

import net.minecraft.world.item.Item;

public class BasicCircuitItem extends Item {
	public BasicCircuitItem() {
		super(new Item.Properties());
	}
}
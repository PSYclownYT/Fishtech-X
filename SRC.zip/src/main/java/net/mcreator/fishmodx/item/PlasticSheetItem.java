package net.mcreator.fishmodx.item;

import net.minecraft.world.item.Item;

public class PlasticSheetItem extends Item {
	public PlasticSheetItem() {
		super(new Item.Properties());
	}
}
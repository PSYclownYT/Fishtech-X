package net.mcreator.fishmodx.item;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

import net.mcreator.fishmodx.init.FishmodxModFluids;

public class MoltenIronItem extends BucketItem {
	public MoltenIronItem() {
		super(FishmodxModFluids.MOLTEN_IRON.get(), new Item.Properties().craftRemainder(Items.BUCKET).stacksTo(1)

		);
	}
}
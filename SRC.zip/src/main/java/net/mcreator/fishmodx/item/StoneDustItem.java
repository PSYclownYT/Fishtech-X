package net.mcreator.fishmodx.item;

import net.minecraft.world.item.Item;

public class StoneDustItem extends Item {
	public StoneDustItem() {
		super(new Item.Properties());
	}
}
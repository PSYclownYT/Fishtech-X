package net.mcreator.fishmodx.item;

import net.minecraft.world.item.Item;

public class SteelItem extends Item {
	public SteelItem() {
		super(new Item.Properties());
	}
}
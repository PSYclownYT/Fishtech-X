package net.mcreator.fishmodx.item;

import net.minecraft.world.item.Item;

public class SiliconWaferItem extends Item {
	public SiliconWaferItem() {
		super(new Item.Properties());
	}
}
package net.mcreator.fishmodx.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class UraniumItem extends Item {
	public UraniumItem() {
		super(new Item.Properties().rarity(Rarity.RARE));
	}
}
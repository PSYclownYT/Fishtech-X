package net.mcreator.fishmodx.item;

import net.minecraft.world.item.Item;

public class LithiumIngotItem extends Item {
	public LithiumIngotItem() {
		super(new Item.Properties());
	}
}
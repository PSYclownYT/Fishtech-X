package net.mcreator.fishmodx.item;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

import net.mcreator.fishmodx.init.FishmodxModFluids;

public class OilItem extends BucketItem {
	public OilItem() {
		super(FishmodxModFluids.OIL.get(), new Item.Properties().craftRemainder(Items.BUCKET).stacksTo(1)

		);
	}
}
package net.mcreator.fishmodx.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class TungstenItem extends Item {
	public TungstenItem() {
		super(new Item.Properties().rarity(Rarity.UNCOMMON));
	}
}
package net.mcreator.fishmodx.item;

import net.minecraft.world.item.Item;

public class MeshItem extends Item {
	public MeshItem() {
		super(new Item.Properties());
	}
}
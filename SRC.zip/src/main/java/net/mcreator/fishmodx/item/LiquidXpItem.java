package net.mcreator.fishmodx.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

import net.mcreator.fishmodx.init.FishmodxModFluids;

public class LiquidXpItem extends BucketItem {
	public LiquidXpItem() {
		super(FishmodxModFluids.LIQUID_XP.get(), new Item.Properties().craftRemainder(Items.BUCKET).stacksTo(1).rarity(Rarity.UNCOMMON));
	}
}
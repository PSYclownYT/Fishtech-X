package net.mcreator.fishmodx.procedures;

import net.neoforged.neoforge.fluids.capability.IFluidHandler;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.common.extensions.ILevelExtension;
import net.neoforged.neoforge.capabilities.Capabilities;

import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

import net.mcreator.fishmodx.init.FishmodxModFluids;

public class LavaExtractionDeviceOnTickUpdateProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		if (("" + world.getBlockState(BlockPos.containing(x, y - 1, z))).contains("minecraft:lava")) {
			if (world instanceof ILevelExtension _ext) {
				IFluidHandler _fluidHandler = _ext.getCapability(Capabilities.FluidHandler.BLOCK, BlockPos.containing(x, y, z), null);
				if (_fluidHandler != null)
					_fluidHandler.fill(new FluidStack(Fluids.LAVA, 50), IFluidHandler.FluidAction.EXECUTE);
			}
		}
		if (("" + world.getBlockState(BlockPos.containing(x, y - 1, z))).contains("fishmodx:oil")) {
			if (world instanceof ILevelExtension _ext) {
				IFluidHandler _fluidHandler = _ext.getCapability(Capabilities.FluidHandler.BLOCK, BlockPos.containing(x, y, z), null);
				if (_fluidHandler != null)
					_fluidHandler.fill(new FluidStack(FishmodxModFluids.OIL.get(), 50), IFluidHandler.FluidAction.EXECUTE);
			}
		}
	}
}
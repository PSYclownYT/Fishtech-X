package net.mcreator.fishmodx.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;
import net.minecraft.core.BlockPos;

import net.mcreator.fishmodx.init.FishmodxModBlocks;

public class OilFinderRightclickedProcedure {
	public static void execute() {
	}

	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal(hasOilReservoirInCurrentChunk(world, entity) ? "Oil reservoir detected in this chunk." : "No oil reservoir detected in this chunk."), true);
	}

	private static boolean hasOilReservoirInCurrentChunk(LevelAccessor world, Entity entity) {
		int chunkMinX = ((int) Math.floor(entity.getX()) >> 4) << 4;
		int chunkMinZ = ((int) Math.floor(entity.getZ()) >> 4) << 4;
		BlockPos.MutableBlockPos mutablePos = new BlockPos.MutableBlockPos();
		for (int x = chunkMinX; x < chunkMinX + 16; x++) {
			for (int z = chunkMinZ; z < chunkMinZ + 16; z++) {
				for (int y = world.getMinBuildHeight(); y < world.getMaxBuildHeight(); y++) {
					if (world.getBlockState(mutablePos.set(x, y, z)).is(FishmodxModBlocks.OIL.get()))
						return true;
				}
			}
		}
		return false;
	}
}
